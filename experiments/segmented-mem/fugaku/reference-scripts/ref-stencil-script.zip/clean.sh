#!/bin/bash
rm -v segment_*
rm -rfv output*
rm -v stencil-script.sh.*
